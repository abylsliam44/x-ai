// nfactorial X Content Platform — v2
// Stage router: one stage in the main viewport at a time, with animated transitions.

const { useState, useEffect, useRef, useMemo } = React;
const D = window.MOCK;

// ─── Icons ──────────────────────────────────────────────────────────
const Icon = ({ name, size = 14, stroke = "currentColor", fill = "none" }) => {
  const p = { width: size, height: size, viewBox: "0 0 24 24", fill, stroke, strokeWidth: 1.6, strokeLinecap: "round", strokeLinejoin: "round" };
  switch (name) {
    case "home":   return <svg {...p}><path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/></svg>;
    case "folder": return <svg {...p}><path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>;
    case "voice":  return <svg {...p}><rect x="9" y="3" width="6" height="12" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/></svg>;
    case "lib":    return <svg {...p}><path d="M4 4h6v16H4zM14 4h6v16h-6zM7 8v8M17 8v8"/></svg>;
    case "spark":  return <svg {...p}><path d="M12 3l1.6 4.5L18 9l-4.4 1.6L12 15l-1.6-4.4L6 9l4.4-1.5z"/></svg>;
    case "traces": return <svg {...p}><path d="M4 7h6l2 4 2-8 2 12 2-4h2"/></svg>;
    case "set":    return <svg {...p}><circle cx="12" cy="12" r="3"/><path d="M19 12a7 7 0 0 0-.1-1.2l2-1.6-2-3.4-2.4.9a7 7 0 0 0-2-1.2L14 3h-4l-.5 2.5a7 7 0 0 0-2 1.2l-2.4-.9-2 3.4 2 1.6A7 7 0 0 0 5 12a7 7 0 0 0 .1 1.2l-2 1.6 2 3.4 2.4-.9a7 7 0 0 0 2 1.2L10 21h4l.5-2.5a7 7 0 0 0 2-1.2l2.4.9 2-3.4-2-1.6c.1-.4.1-.8.1-1.2z"/></svg>;
    case "search": return <svg {...p}><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg>;
    case "play":   return <svg {...p}><polygon points="6 4 20 12 6 20"/></svg>;
    case "rocket": return <svg {...p}><path d="M14 4l6 6-9 9-3 3-3-3 3-3 9-9z"/><path d="M14 10l4 4M5 21l-1-1"/></svg>;
    case "scan":   return <svg {...p}><path d="M4 7V5a2 2 0 0 1 2-2h2M16 3h2a2 2 0 0 1 2 2v2M20 17v2a2 2 0 0 1-2 2h-2M8 21H6a2 2 0 0 1-2-2v-2M4 12h16"/></svg>;
    case "fork":   return <svg {...p}><circle cx="6" cy="6" r="2"/><circle cx="18" cy="6" r="2"/><circle cx="12" cy="20" r="2"/><path d="M6 8v3a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V8M12 13v5"/></svg>;
    case "pen":    return <svg {...p}><path d="M3 21l4-1 12-12-3-3L4 17z"/></svg>;
    case "check":  return <svg {...p}><polyline points="4 12 10 18 20 6"/></svg>;
    case "vector": return <svg {...p}><circle cx="6" cy="6" r="2"/><circle cx="18" cy="18" r="2"/><path d="M8 8l8 8M6 18l12-12"/></svg>;
    case "edit":   return <svg {...p}><path d="M14 4l6 6-10 10H4v-6z"/></svg>;
    case "tree":   return <svg {...p}><path d="M12 4v6M6 14h12M6 14v6M18 14v6M12 10v4"/></svg>;
    case "wave":   return <svg {...p}><path d="M3 12c2 0 2-4 4-4s2 8 4 8 2-8 4-8 2 4 4 4 2 0 2 0"/></svg>;
    case "rt":     return <svg {...p}><path d="M17 1l4 4-4 4M3 11V9a4 4 0 0 1 4-4h14M7 23l-4-4 4-4M21 13v2a4 4 0 0 1-4 4H3"/></svg>;
    case "heart":  return <svg {...p}><path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 1 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8z"/></svg>;
    case "reply":  return <svg {...p}><path d="M3 12h13a5 5 0 0 1 5 5v2M3 12l5-5M3 12l5 5"/></svg>;
    case "share":  return <svg {...p}><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8M16 6l-4-4-4 4M12 2v13"/></svg>;
    default: return <svg {...p}><circle cx="12" cy="12" r="3"/></svg>;
  }
};

// ─── Sidebar ───────────────────────────────────────────────────────
const Sidebar = () => (
  <aside className="sidebar">
    <div className="nav-group">
      <div className="nav-label">Workspace</div>
      <div className="nav-item"><Icon name="home" /> <span>Dashboard</span><span /></div>
      <div className="nav-item active"><Icon name="folder" /> <span>Projects</span><span className="count">12</span></div>
      <div className="nav-item"><Icon name="spark" /> <span>Brand voice</span><span /></div>
      <div className="nav-item"><Icon name="lib" /> <span>Writing samples</span><span className="count">24</span></div>
      <div className="nav-item"><Icon name="voice" /> <span>Voice notes</span><span className="count">3</span></div>
    </div>

    <div className="nav-group">
      <div className="nav-label">System</div>
      <div className="nav-item"><Icon name="traces" /> <span>Agent traces</span><span /></div>
      <div className="nav-item"><Icon name="set" /> <span>Settings</span><span /></div>
    </div>

    <div className="x-card">
      <div className="label">X Connection</div>
      <div className="name">{D.xAccount.name}</div>
      <div className="handle">{D.xAccount.handle}</div>
      <div className="row">
        <span><span className="num" style={{ color: "var(--text)" }}>4,218</span> followers</span>
        <span><span className="num" style={{ color: "var(--green)" }}>●</span> live</span>
      </div>
    </div>
  </aside>
);

// ─── Topbar ────────────────────────────────────────────────────────
const Topbar = ({ onPublish }) => (
  <div className="topbar">
    <div className="brand">
      <div className="mark" />
      <h1>nfactorial<sup>X-CTRL</sup></h1>
    </div>
    <div className="crumbs">
      <div className="pill"><span className="dot" /> Drafting</div>
      <span>•</span>
      <span className="pname">Why we're building agentic content infra</span>
      <span className="pid">{D.project.id}</span>
    </div>
    <div className="top-actions">
      <div className="chip"><span className="gd" /> X API · 287/300</div>
      <div className="chip">⌘K · search</div>
      <button className="btn"><Icon name="play" size={12} /> Re-run</button>
      <button className="btn btn-primary btn-lg" onClick={onPublish}><Icon name="rocket" size={13} /> Review & publish</button>
    </div>
  </div>
);

// ─── Pipeline flow diagram (animated SVG) ──────────────────────────
const STAGES = [
  { id: "sources",  num: "01", name: "Sources",   sub: "5 retained",    icon: "scan",  agentId: "research" },
  { id: "insights", num: "02", name: "Insights",  sub: "3 extracted",   icon: "spark", agentId: "insight" },
  { id: "angles",   num: "03", name: "Angles",    sub: "1 selected",    icon: "fork",  agentId: "angle" },
  { id: "draft",    num: "04", name: "Draft",     sub: "thread · 5",    icon: "pen",   agentId: "writer" },
  { id: "review",   num: "05", name: "Review",    sub: "82% / 91%",     icon: "check", agentId: "factcheck" },
  { id: "publish",  num: "06", name: "Publish",   sub: "ready",         icon: "rocket", agentId: "publisher" },
];

const PipelineFlow = ({ active, onPick }) => {
  // Node positions in a 1200x132 viewBox region; we calculate left % at runtime.
  const idx = STAGES.findIndex(s => s.id === active);
  const progressPct = ((idx) / (STAGES.length - 1)) * 100;
  const ref = useRef(null);
  const [w, setW] = useState(1100);

  useEffect(() => {
    if (!ref.current) return;
    const ro = new ResizeObserver(() => { setW(ref.current.clientWidth); });
    ro.observe(ref.current);
    return () => ro.disconnect();
  }, []);

  const px = (i) => 80 + ((w - 160 - 100) * i / (STAGES.length - 1));
  const cy = 56;

  return (
    <div className="flow" ref={ref}>
      <svg viewBox={`0 0 ${w} 132`} preserveAspectRatio="none">
        {/* base line */}
        <line x1="80" y1={cy} x2={w - 100} y2={cy} stroke="rgba(120,140,200,.15)" strokeWidth="1.2" />
        {/* active progress line */}
        <line x1="80" y1={cy} x2={80 + ((w - 180) * progressPct / 100)} y2={cy} stroke="url(#flowG)" strokeWidth="2" />
        {/* animated dots */}
        <line x1="80" y1={cy} x2={w - 100} y2={cy} stroke="url(#flowDots)" strokeWidth="2" strokeDasharray="3 8">
          <animate attributeName="stroke-dashoffset" from="0" to="-22" dur="1.6s" repeatCount="indefinite" />
        </line>
        <defs>
          <linearGradient id="flowG" x1="0" x2="1">
            <stop offset="0%" stopColor="#3ddc97" />
            <stop offset="100%" stopColor="#5b9eff" />
          </linearGradient>
          <linearGradient id="flowDots" x1="0" x2="1">
            <stop offset="0%" stopColor="rgba(91,158,255,0)" />
            <stop offset="50%" stopColor="rgba(91,158,255,.55)" />
            <stop offset="100%" stopColor="rgba(167,139,255,0)" />
          </linearGradient>
        </defs>
      </svg>

      {STAGES.map((s, i) => {
        const status = i < idx ? "done" : (i === idx ? "active" : "queued");
        return (
          <div key={s.id} className={`flow-node ${status}`}
               style={{ left: `${(px(i) / w) * 100}%`, top: `${cy}px` }}
               onClick={() => onPick(s.id)}>
            <div className="ring"><Icon name={s.icon} size={16} /></div>
            <div className="lbl">{s.name}</div>
            <div className="sub">{s.num} · {s.sub}</div>
          </div>
        );
      })}
    </div>
  );
};

// ─── Project header ────────────────────────────────────────────────
const ProjectHeader = () => (
  <div className="ph">
    <div>
      <div className="label">Project · thread · 5 posts</div>
      <h2>Why we're building agentic content infra</h2>
      <p>Distribution is the new moat for AI-native startups. Goal: provoke + announce thesis ahead of Series A. Audience: founders, operators, technical investors.</p>
    </div>
    <div className="meta-bar">
      <div className="m"><div className="mk">Voice</div><div className="mv">Sharp Operator</div></div>
      <div className="m"><div className="mk">Quality</div><div className="mv good">0.86</div></div>
      <div className="m"><div className="mk">Fact</div><div className="mv warn">0.82</div></div>
      <div className="m"><div className="mk">Style</div><div className="mv good">0.91</div></div>
    </div>
  </div>
);

// ─── Stage: Sources ────────────────────────────────────────────────
const StageSources = () => {
  const [sel, setSel] = useState(D.sources[0].id);
  const cur = D.sources.find(s => s.id === sel);
  const typeMap = { article: "ART", x_post: "X", paper: "DOI", upload: "PDF", url: "URL" };
  return (
    <div className="stage-body src-grid">
      <div className="src-list">
        {D.sources.map(s => (
          <div key={s.id} className={"src-row" + (s.id === sel ? " sel" : "")} onClick={() => setSel(s.id)}>
            <div className="src-tag">{typeMap[s.type]}</div>
            <div>
              <div className="src-title">{s.title}</div>
              <div className="src-snip">"{s.snippet}"</div>
              <div className="src-meta">{s.author} · {s.domain} · {s.date}</div>
            </div>
            <div className="src-cred">
              <span>{s.credibility.toFixed(2)}</span>
              <span className="bar"><i style={{ width: `${s.credibility * 100}%` }} /></span>
            </div>
          </div>
        ))}
      </div>
      <div className="src-preview">
        <div className="pv-head">
          <div className="src-tag">{typeMap[cur.type]}</div>
          <div>
            <div className="src-title">{cur.title}</div>
            <div className="src-meta">{cur.author} · {cur.domain} · {cur.date}</div>
          </div>
        </div>
        <div className="pv-quote">"{cur.snippet}"</div>
        <div className="stat-row">
          <div className="stat">
            <div className="k">Credibility</div>
            <div className="v num">{cur.credibility.toFixed(2)}</div>
          </div>
          <div className="stat">
            <div className="k">Citations</div>
            <div className="v num">{cur.type === "upload" ? 2 : 1}</div>
          </div>
        </div>
        <div style={{ marginTop: 16, fontSize: 12.5, color: "var(--text-2)", lineHeight: 1.55 }}>
          <strong style={{ color: "var(--text)", fontWeight: 500 }}>Why retained:</strong> credibility ≥ 0.75 threshold, claim density high, no contradiction with other retained sources.
        </div>
        <div style={{ display: "flex", gap: 8, marginTop: 14, flexWrap: "wrap" }}>
          {cur.tags.map(t => <span key={t} style={{ fontFamily: "var(--mono)", fontSize: 11, padding: "4px 8px", border: "1px solid var(--line-2)", borderRadius: 999, color: "var(--text-2)" }}>#{t}</span>)}
        </div>
      </div>
    </div>
  );
};

// ─── Stage: Insights ───────────────────────────────────────────────
const StageInsights = () => (
  <div className="stage-body">
    <div className="ins-grid">
      {D.insights.map((i, ix) => (
        <div key={i.id} className="ins-card">
          <div className="ic-num">{String(ix + 1).padStart(2, "0")}</div>
          <div className="ic-tag">Insight · strength {i.strength.toFixed(2)}</div>
          <div className="ic-claim">{i.claim}</div>
          <div className="ic-why">{i.why}</div>
          <div className="ic-angle">↳ {i.angle}</div>
          <div className="ic-foot">
            <span>strength</span>
            <span className="bar"><i style={{ width: `${i.strength * 100}%` }} /></span>
            <span className="num" style={{ color: "var(--text-2)" }}>{i.strength.toFixed(2)}</span>
          </div>
        </div>
      ))}
    </div>
  </div>
);

// ─── Stage: Angles ─────────────────────────────────────────────────
const StageAngles = ({ pick, setPick }) => (
  <div className="stage-body">
    <div className="ang-grid">
      {D.angles.map(a => (
        <div key={a.id} className={"ang-card" + (a.id === pick ? " sel" : "")} onClick={() => setPick(a.id)}>
          <div className="ac-row">
            <div className="ac-title">{a.title}</div>
            <div className="ac-score">★ {a.score.toFixed(1)}</div>
          </div>
          <div className="ac-thesis">{a.thesis}</div>
          <div className="ac-foot">
            <span><Icon name="fork" size={11} /> {a.format}</span>
            <span>·</span>
            <span>{a.tone}</span>
            {a.id === pick && <span className="sel-pill"><Icon name="check" size={11} /> Selected</span>}
          </div>
        </div>
      ))}
    </div>
  </div>
);

// ─── Stage: Draft (composer + live X-style preview) ────────────────
const StageDraft = ({ typingDone, onPublish }) => {
  const posts = D.draft.posts;
  const [typed, setTyped] = useState(typingDone ? posts.length : 0);
  const [charPos, setCharPos] = useState(typingDone ? 9999 : 0);

  useEffect(() => {
    if (typingDone) { setTyped(posts.length); setCharPos(9999); return; }
    let stopped = false;
    let cur = 0, pos = 0;
    const step = () => {
      if (stopped) return;
      const post = posts[cur];
      if (!post) { setTyped(posts.length); return; }
      pos += Math.max(1, Math.floor(Math.random() * 4));
      if (pos >= post.length) {
        setCharPos(post.length); setTyped(cur + 1);
        cur += 1; pos = 0;
        if (cur >= posts.length) return;
        setTimeout(step, 380);
      } else {
        setCharPos(pos);
        setTimeout(step, 18 + Math.random() * 24);
      }
    };
    setTimeout(step, 500);
    return () => { stopped = true; };
  }, [typingDone]);

  return (
    <div className="stage-body draft-split">
      <div className="draft-col">
        <h4>Composer · thread · {typed}/{posts.length}</h4>
        {posts.map((p, i) => {
          if (i > typed) return null;
          const isTyping = i === typed && !typingDone;
          const visible = i < typed ? p : (isTyping ? p.slice(0, charPos) : "");
          const len = visible.length;
          return (
            <div key={i} className="tp">
              <div className={"ix" + (isTyping ? " streaming" : "")}>{i + 1}</div>
              <div className="text">
                {highlightCites(visible)}
                {isTyping && <span className="typing" />}
              </div>
              <div className="foot">
                <span className={"len" + (len > 280 ? " over" : "")}>{len}/280</span>
                {i > 0 && <span>reply to post {i}</span>}
                {i === 1 && <span className="cite-tag">2 citations</span>}
                {i === 4 && <span className="style-flag">tighten ending</span>}
              </div>
            </div>
          );
        })}
      </div>

      <div className="draft-col">
        <h4>Live preview · publishes as {D.xAccount.handle}</h4>
        <div className="preview-stack">
          {posts.slice(0, 3).map((p, i) => (
            <React.Fragment key={i}>
              <div className={"pv" + (i === 0 ? " first" : "")}>
                <div className="pv-h">
                  <div className="pv-av"><span>{D.xAccount.avatarSeed.toUpperCase()}</span></div>
                  <div>
                    <div className="pv-name">{D.xAccount.name}</div>
                    <div className="pv-handle">{D.xAccount.handle}</div>
                  </div>
                  <div className="pv-time">now</div>
                </div>
                <div className="pv-body">{p}</div>
                <div className="pv-foot">
                  <span><Icon name="reply" size={13} /> 12</span>
                  <span><Icon name="rt" size={13} /> 4</span>
                  <span><Icon name="heart" size={13} /> 28</span>
                  <span><Icon name="share" size={13} /></span>
                </div>
              </div>
              {i < 2 && <div className="pv-link" />}
            </React.Fragment>
          ))}
          <div style={{ textAlign: "center", padding: "10px 0", fontFamily: "var(--mono)", fontSize: 11.5, color: "var(--text-3)", letterSpacing: ".1em" }}>
            + 2 more posts in chain
          </div>
        </div>

        <div className="telemetry">
          <div className="tm-h"><span className="live" /> Quality telemetry · live</div>
          <div className="meter-row"><span className="mk">Quality</span><span className="mbar"><i style={{ width: "86%", background: "var(--blue)", color: "var(--blue)" }} /></span><span className="mv">0.86</span></div>
          <div className="meter-row"><span className="mk">Fact conf.</span><span className="mbar"><i style={{ width: "82%", background: "var(--warn)", color: "var(--warn)" }} /></span><span className="mv">0.82</span></div>
          <div className="meter-row"><span className="mk">Style</span><span className="mbar"><i style={{ width: "91%", background: "var(--green)", color: "var(--green)" }} /></span><span className="mv">0.91</span></div>
          <div className="meter-row"><span className="mk">Hook</span><span className="mbar"><i style={{ width: "94%", background: "var(--violet)", color: "var(--violet)" }} /></span><span className="mv">0.94</span></div>
        </div>
      </div>
    </div>
  );
};

function highlightCites(text) {
  const re = /(38%|41%|22%|73%|0\.92)/g;
  const parts = [];
  let last = 0, m;
  while ((m = re.exec(text)) !== null) {
    if (m.index > last) parts.push(text.slice(last, m.index));
    parts.push(<span key={m.index} className="cite" title={"fact-checked · " + m[0]}>{m[0]}</span>);
    last = m.index + m[0].length;
  }
  if (last < text.length) parts.push(text.slice(last));
  return parts;
}

// ─── Stage: Fact + Style Review ────────────────────────────────────
const StageReview = () => {
  const verdictLabel = { supported: "Supported", weakly_supported: "Weak", needs_source: "Needs source", unsupported: "Unsupported" };
  const verdictCls = { supported: "v-supported", weakly_supported: "v-weak", needs_source: "v-needs", unsupported: "v-needs" };
  const overall = D.draft.fact_confidence;
  const circumference = 2 * Math.PI * 70;
  const dash = circumference * overall;

  return (
    <div className="stage-body">
      <div className="fs-grid">
        <div>
          <h4 style={{ font: "500 11px var(--mono)", letterSpacing: ".18em", textTransform: "uppercase", color: "var(--text-3)", marginTop: 0, marginBottom: 12 }}>Fact check · 5 claims</h4>
          {D.factChecks.map(f => (
            <div key={f.id} className="fc">
              <div>
                <div className="claim">"{f.claim}"</div>
                <div className="src">↳ {f.source || "no source — needs review"}</div>
                <div className="cf">
                  <span>confidence</span>
                  <span className="mb"><i style={{ width: `${f.conf * 100}%`, background: f.conf > .8 ? "var(--green)" : f.conf > .6 ? "var(--warn)" : "var(--danger)" }} /></span>
                  <span className="num" style={{ color: "var(--text-2)" }}>{f.conf.toFixed(2)}</span>
                </div>
              </div>
              <div className={"verdict " + verdictCls[f.verdict]}>{verdictLabel[f.verdict]}</div>
            </div>
          ))}
        </div>

        <div>
          <div className="conf-orb">
            <svg className="ring-svg" viewBox="0 0 160 160">
              <defs>
                <linearGradient id="confg" x1="0" x2="1">
                  <stop offset="0%" stopColor="#ffb454" />
                  <stop offset="100%" stopColor="#5b9eff" />
                </linearGradient>
                <radialGradient id="confbg">
                  <stop offset="60%" stopColor="rgba(91,158,255,.15)" />
                  <stop offset="100%" stopColor="transparent" />
                </radialGradient>
              </defs>
              <circle cx="80" cy="80" r="78" fill="url(#confbg)" />
              <circle cx="80" cy="80" r="70" fill="none" stroke="rgba(120,140,200,.12)" strokeWidth="6" />
              <circle cx="80" cy="80" r="70" fill="none" stroke="url(#confg)" strokeWidth="6"
                strokeDasharray={`${dash} ${circumference - dash}`}
                strokeDashoffset="0"
                transform="rotate(-90 80 80)"
                strokeLinecap="round"
                style={{ filter: "drop-shadow(0 0 8px rgba(91,158,255,.5))" }}
              />
              <text x="80" y="78" textAnchor="middle" fill="#fff" style={{ fontFamily: "var(--mono)", fontSize: 32, fontWeight: 600 }}>{Math.round(overall * 100)}</text>
              <text x="80" y="100" textAnchor="middle" fill="var(--text-3)" style={{ fontFamily: "var(--mono)", fontSize: 10, letterSpacing: "0.16em" }}>OVERALL %</text>
            </svg>
            <div style={{ marginTop: 6, color: "var(--text-2)", fontSize: 13 }}>3 supported · 1 weak · 1 needs source</div>
          </div>

          <div style={{ marginTop: 16 }}>
            <h4 style={{ font: "500 11px var(--mono)", letterSpacing: ".18em", textTransform: "uppercase", color: "var(--text-3)", margin: "0 0 10px" }}>Style review · sharp operator</h4>
            {D.styleNotes.map((n, i) => (
              <div key={i} className={"stnote " + n.severity}>
                <span className="badge">{n.severity === "good" ? "OK" : "ATTN"}</span>
                <span className="kind">{n.kind}</span>
                <span className="note">{n.note}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

// ─── Stage: Publish ────────────────────────────────────────────────
const StagePublish = ({ onPublish }) => {
  const checks = [
    { ok: true,  label: "X account connected",    val: D.xAccount.handle },
    { ok: true,  label: "Brand voice applied",     val: "Sharp Operator" },
    { ok: true,  label: "Thread structure valid",  val: "5 / 5 posts < 280" },
    { ok: false, label: "1 claim needs a source",  val: "f4 · software margins" },
    { ok: true,  label: "Style review passed",      val: "0.91" },
    { ok: true,  label: "API rate limit",          val: "287 / 300" },
  ];
  return (
    <div className="stage-body pub-shell">
      <div className="pub-prevs">
        <h4 style={{ font: "500 11px var(--mono)", letterSpacing: ".18em", textTransform: "uppercase", color: "var(--text-3)", marginTop: 0, marginBottom: 10 }}>Final preview · publishing as {D.xAccount.handle}</h4>
        {D.draft.posts.slice(0, 3).map((p, i) => (
          <React.Fragment key={i}>
            <div className={"pv" + (i === 0 ? " first" : "")}>
              <div className="pv-h">
                <div className="pv-av"><span>{D.xAccount.avatarSeed.toUpperCase()}</span></div>
                <div>
                  <div className="pv-name">{D.xAccount.name}</div>
                  <div className="pv-handle">{D.xAccount.handle}</div>
                </div>
                <div className="pv-time">scheduled</div>
              </div>
              <div className="pv-body">{p}</div>
            </div>
            {i < 2 && <div className="pv-link" />}
          </React.Fragment>
        ))}
        <div style={{ textAlign: "center", padding: "10px 0", fontFamily: "var(--mono)", fontSize: 11.5, color: "var(--text-3)" }}>+ 2 more posts in chain</div>
      </div>

      <div className="pub-launch">
        <div className="pl-h">Launch sequence</div>
        <div className="pl-sub">Every claim has a source bound or is flagged for review. Publish creates a reply chain via X API.</div>

        <div className="pl-checks">
          {checks.map((c, i) => (
            <div key={i} className="pl-check">
              <span className={c.ok ? "c-ok" : "c-warn"}>{c.ok ? "✓" : "⚠"}</span>
              <span>{c.label}</span>
              <span className="c-val">{c.val}</span>
            </div>
          ))}
        </div>

        <div className="schedule-bar">
          <span className="sb-label">Schedule</span>
          <span className="sb-time">Today · 14:30 UTC</span>
          <span className="sp" />
          <button className="btn btn-ghost" style={{ height: 26, padding: "0 10px", fontSize: 12 }}>edit</button>
        </div>

        <button className="launch-btn" onClick={onPublish}>
          <Icon name="rocket" size={16} />
          Approve & publish thread
        </button>
      </div>
    </div>
  );
};

// ─── Stage router ──────────────────────────────────────────────────
const Stage = ({ id, picks, setPicks, onPublish, typingDone }) => {
  const meta = STAGES.find(s => s.id === id);
  const header = (() => {
    switch (id) {
      case "sources":  return { d: "5 retained from 12 candidates · credibility ≥ 0.75" };
      case "insights": return { d: "Non-obvious, evidence-backed, scored 0–1" };
      case "angles":   return { d: "4 ranked · click to switch the active draft" };
      case "draft":    return { d: "writer-agent · streaming · claude-sonnet-4.5" };
      case "review":   return { d: "Fact-check + style review · brand voice gated" };
      case "publish":  return { d: "Approve & publish to X via reply chain" };
      default: return { d: "" };
    }
  })();
  return (
    <div className="stage-shell" key={id}>
      <div className="stage-header">
        <span className="num">{meta.num}</span>
        <h3>{meta.name}</h3>
        <span className="desc">{header.d}</span>
        <div className="actions">
          {id !== "publish" && <button className="btn btn-ghost"><Icon name="play" size={12} /> Re-run</button>}
          {id === "draft" && <button className="btn btn-ghost"><Icon name="edit" size={12} /> Revise</button>}
          {id === "draft" && <button className="btn btn-primary" onClick={onPublish}><Icon name="rocket" size={12} /> Approve</button>}
          {id !== "draft" && id !== "publish" && <button className="btn">Continue →</button>}
        </div>
      </div>
      {id === "sources"  && <StageSources />}
      {id === "insights" && <StageInsights />}
      {id === "angles"   && <StageAngles pick={picks.angle} setPick={(v) => setPicks(p => ({ ...p, angle: v }))} />}
      {id === "draft"    && <StageDraft typingDone={typingDone} onPublish={onPublish} />}
      {id === "review"   && <StageReview />}
      {id === "publish"  && <StagePublish onPublish={onPublish} />}
    </div>
  );
};

// ─── Right rail: Agent dock ────────────────────────────────────────
const AgentDock = ({ openId, setOpen, elapsedMs, activeStage }) => {
  // Highlight the agent linked to the currently visible stage
  const currentAgent = STAGES.find(s => s.id === activeStage)?.agentId;
  return (
    <aside className="dock">
      <div className="dock-h"><span className="ld" /> Agent pipeline</div>

      {D.agents.map(a => {
        const ms = a.status === "running" ? elapsedMs : a.ms;
        const open = openId === a.id;
        const tag = a.id === currentAgent;
        return (
          <div key={a.id} className={"ag " + a.status + (open ? " open" : "")}
               onClick={() => setOpen(open ? null : a.id)}
               style={tag ? { boxShadow: "inset 0 0 0 1px rgba(91,158,255,.25)", background: "rgba(91,158,255,.06)" } : null}>
            <div className="icon"><Icon name={a.icon} size={13} /></div>
            <div>
              <div className="name">{a.name}</div>
              <div className="sub">
                {a.status === "done"    && `${(a.tokens / 1000).toFixed(1)}k tok`}
                {a.status === "running" && "streaming…"}
                {a.status === "queued"  && "queued"}
              </div>
            </div>
            <div className="right">{ms ? `${(ms / 1000).toFixed(2)}s` : "—"}</div>
            {open && (
              <div className="detail" onClick={(e) => e.stopPropagation()}>
                <div className="r"><span className="k">model</span><span>{a.model}</span></div>
                <div className="r"><span className="k">tokens</span><span>{a.tokens.toLocaleString()}</span></div>
                <div className="r"><span className="k">latency</span><span>{ms ? ms + "ms" : "—"}</span></div>
                <div className="r"><span className="k">status</span><span style={{ color: a.status === "done" ? "var(--green)" : a.status === "running" ? "var(--blue)" : "var(--text-3)" }}>{a.status}</span></div>
                {a.id === "writer" && <div className="r"><span className="k">stream</span><span>post[2/5]…</span></div>}
              </div>
            )}
          </div>
        );
      })}

      <div className="cost-card">
        <div className="h">Run cost · this project</div>
        <div className="row"><span className="k">Tokens</span><span className="v">35,990</span></div>
        <div className="row"><span className="k">Tool calls</span><span className="v">14</span></div>
        <div className="row"><span className="k">Est. cost</span><span className="v" style={{ color: "var(--blue)" }}>$0.142</span></div>
        <div className="row"><span className="k">Budget</span><span className="v">$2.00</span></div>
      </div>
    </aside>
  );
};

// ─── Publish modal ─────────────────────────────────────────────────
const PublishModal = ({ onClose }) => {
  const [phase, setPhase] = useState("review");
  const ts = useRef(null);
  const start = () => {
    setPhase("publishing");
    ts.current = setTimeout(() => setPhase("done"), 2200);
  };
  useEffect(() => () => { if (ts.current) clearTimeout(ts.current); }, []);

  return (
    <div className="modal-back" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <div style={{ width: 36, height: 36, borderRadius: 10, background: "linear-gradient(135deg,var(--blue),var(--violet))", display: "flex", alignItems: "center", justifyContent: "center", boxShadow: "0 0 20px rgba(91,158,255,.5)" }}>
            <Icon name="rocket" size={18} stroke="#fff" />
          </div>
          <div>
            <div className="modal-h">
              {phase === "review" && "Approve & publish to X"}
              {phase === "publishing" && "Publishing thread…"}
              {phase === "done" && "Published"}
            </div>
            <div className="modal-sub">
              {phase === "review" && `Thread · 5 posts · ${D.xAccount.handle}`}
              {phase === "publishing" && "Reply chain · awaiting X API confirmation"}
              {phase === "done" && "Reply chain created in 2.18s. Open on X to verify."}
            </div>
          </div>
        </div>

        {phase === "review" && (
          <div>
            <div style={{ padding: 14, marginTop: 18, background: "rgba(255,180,84,.06)", border: "1px solid rgba(255,180,84,.3)", borderRadius: 10, fontSize: 13 }}>
              <div style={{ color: "var(--warn)", fontFamily: "var(--mono)", fontSize: 10.5, letterSpacing: ".14em", textTransform: "uppercase" }}>● Review note</div>
              <div style={{ color: "var(--text)", marginTop: 6 }}>
                Claim "Software margins deflating to zero" needs a source. Publish anyway, or pause to add one?
              </div>
            </div>
            <div className="modal-actions">
              <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
              <button className="btn">Pause · add source</button>
              <button className="btn btn-primary" onClick={start}><Icon name="rocket" size={12} /> Publish now</button>
            </div>
          </div>
        )}

        {phase === "publishing" && (
          <div style={{ marginTop: 18 }}>
            {["Uploading media", "Creating post 1/5", "Reply chain 2/5", "Reply chain 3/5", "Reply chain 4/5", "Reply chain 5/5", "Confirming"].map((s, i) => (
              <div key={i} style={{ display: "grid", gridTemplateColumns: "20px 1fr auto", gap: 10, padding: "6px 0", fontFamily: "var(--mono)", fontSize: 12 }}>
                <span style={{ color: i < 4 ? "var(--green)" : i === 4 ? "var(--blue)" : "var(--text-3)" }}>{i < 4 ? "✓" : i === 4 ? "▸" : " "}</span>
                <span style={{ color: i <= 4 ? "var(--text)" : "var(--text-3)" }}>{s}</span>
                <span style={{ color: "var(--text-3)" }}>{i < 4 ? `${(0.2 + i * 0.18).toFixed(2)}s` : ""}</span>
              </div>
            ))}
            <div style={{ height: 5, background: "rgba(255,255,255,.06)", borderRadius: 3, overflow: "hidden", marginTop: 16 }}>
              <div style={{ height: "100%", width: "62%", background: "linear-gradient(90deg,var(--blue),var(--violet))", boxShadow: "0 0 14px var(--blue)" }} />
            </div>
          </div>
        )}

        {phase === "done" && (
          <div style={{ marginTop: 18 }}>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
              <div style={{ padding: 12, border: "1px solid var(--line)", borderRadius: 8 }}>
                <div className="mono" style={{ fontSize: 10, color: "var(--text-3)", letterSpacing: ".14em", textTransform: "uppercase" }}>thread URL</div>
                <div className="mono" style={{ fontSize: 12, color: "var(--blue)", marginTop: 4, wordBreak: "break-all" }}>x.com/nfactorial_hq/status/19283…</div>
              </div>
              <div style={{ padding: 12, border: "1px solid var(--line)", borderRadius: 8 }}>
                <div className="mono" style={{ fontSize: 10, color: "var(--text-3)", letterSpacing: ".14em", textTransform: "uppercase" }}>publish log</div>
                <div className="mono" style={{ fontSize: 12, color: "var(--green)", marginTop: 4 }}>✓ 5/5 posts · 2.18s</div>
              </div>
            </div>
            <div className="modal-actions">
              <button className="btn" onClick={onClose}>Close</button>
              <button className="btn btn-primary">Open on X →</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

// ─── App ───────────────────────────────────────────────────────────
const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "default",
  "density": "regular",
  "motion": "rich",
  "fastTyping": false
}/*EDITMODE-END*/;

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [active, setActive] = useState("draft");
  const [picks, setPicks] = useState({ angle: "a1" });
  const [openAgent, setOpenAgent] = useState(null);
  const [showPublish, setShowPublish] = useState(false);
  const [elapsed, setElapsed] = useState(2840);

  useEffect(() => { document.body.dataset.density = t.density; }, [t.density]);
  useEffect(() => { document.body.dataset.accent  = t.accent;  }, [t.accent]);
  useEffect(() => { document.body.dataset.motion  = t.motion;  }, [t.motion]);

  useEffect(() => {
    const id = setInterval(() => setElapsed(e => e + 60 + Math.random() * 40), 100);
    return () => clearInterval(id);
  }, []);

  return (
    <>
      <Topbar onPublish={() => setShowPublish(true)} />
      <div className="layout">
        <Sidebar />
        <main className="main">
          <ProjectHeader />
          <PipelineFlow active={active} onPick={setActive} />
          <Stage id={active} picks={picks} setPicks={setPicks}
                 onPublish={() => setShowPublish(true)}
                 typingDone={t.fastTyping} />
        </main>
        <AgentDock openId={openAgent} setOpen={setOpenAgent} elapsedMs={Math.floor(elapsed)} activeStage={active} />
      </div>

      {showPublish && <PublishModal onClose={() => setShowPublish(false)} />}

      <TweaksPanel title="Tweaks">
        <TweakSection label="Theme" />
        <TweakRadio label="Accent" value={t.accent}
          options={["default", "green", "cyber", "amber", "mono"]}
          onChange={(v) => setTweak("accent", v)} />
        <TweakSection label="Layout" />
        <TweakRadio label="Density" value={t.density}
          options={["compact", "regular", "comfy"]}
          onChange={(v) => setTweak("density", v)} />
        <TweakSection label="Motion" />
        <TweakRadio label="Animation" value={t.motion}
          options={["low", "medium", "rich"]}
          onChange={(v) => setTweak("motion", v)} />
        <TweakToggle label="Skip typing animation" value={t.fastTyping}
          onChange={(v) => setTweak("fastTyping", v)} />
        <TweakSection label="Quick jump" />
        <TweakRadio label="Active stage" value={active}
          options={["sources", "insights", "angles", "draft", "review", "publish"]}
          onChange={setActive} />
      </TweaksPanel>
    </>
  );
}

ReactDOM.createRoot(document.getElementById("app")).render(<App />);
