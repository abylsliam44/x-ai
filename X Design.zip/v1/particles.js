// Subtle starfield with occasional drift lines. Plays under the UI.
(function () {
  const cvs = document.getElementById("particle-canvas");
  if (!cvs) return;
  const ctx = cvs.getContext("2d");
  let W = 0, H = 0, dpr = Math.min(window.devicePixelRatio || 1, 2);
  let stars = [];
  let lines = [];
  let raf = 0;
  let last = performance.now();

  function resize() {
    W = window.innerWidth;
    H = window.innerHeight;
    cvs.width = Math.floor(W * dpr);
    cvs.height = Math.floor(H * dpr);
    cvs.style.width = W + "px";
    cvs.style.height = H + "px";
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    const n = Math.floor((W * H) / 14000);
    stars = new Array(n).fill(0).map(() => ({
      x: Math.random() * W,
      y: Math.random() * H,
      r: Math.random() * 1.2 + 0.2,
      a: Math.random() * 0.4 + 0.2,
      tw: Math.random() * Math.PI * 2,
      sp: 0.5 + Math.random() * 1.2,
      hue: Math.random() < 0.85 ? 215 : 265,
    }));
  }

  function spawnLine() {
    const dir = Math.random() < 0.5 ? 1 : -1;
    const y = Math.random() * H;
    lines.push({
      x: dir > 0 ? -120 : W + 120,
      y, dir, life: 0,
      len: 80 + Math.random() * 160,
      sp: 1.4 + Math.random() * 2.2,
      hue: Math.random() < 0.5 ? 215 : 265,
    });
  }

  function frame(now) {
    const dt = Math.min(64, now - last); last = now;
    ctx.clearRect(0, 0, W, H);

    // stars
    for (const s of stars) {
      s.tw += dt * 0.002 * s.sp;
      const a = s.a * (0.6 + 0.4 * Math.sin(s.tw));
      ctx.beginPath();
      ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
      ctx.fillStyle = `hsla(${s.hue},90%,72%,${a})`;
      ctx.fill();
    }

    // ambient lines
    if (Math.random() < 0.012) spawnLine();
    lines = lines.filter(l => {
      l.life += dt;
      l.x += l.dir * l.sp;
      const grad = ctx.createLinearGradient(l.x - l.dir * l.len, l.y, l.x, l.y);
      grad.addColorStop(0, `hsla(${l.hue},90%,70%,0)`);
      grad.addColorStop(1, `hsla(${l.hue},90%,70%,.55)`);
      ctx.strokeStyle = grad;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(l.x - l.dir * l.len, l.y);
      ctx.lineTo(l.x, l.y);
      ctx.stroke();
      return l.dir > 0 ? l.x < W + 200 : l.x > -200;
    });

    raf = requestAnimationFrame(frame);
  }

  resize();
  window.addEventListener("resize", resize);
  raf = requestAnimationFrame(frame);
})();
