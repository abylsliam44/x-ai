// nfactorial X Content Platform — Project Workspace
// Hi-fi interactive prototype: pipeline of agents from sources → publish.

const { useState, useEffect, useRef, useMemo } = React;
const D = window.MOCK;

// ─── Tiny icons (line, mono) ────────────────────────────────────────
const Icon = ({ name, size = 14, stroke = "currentColor" }) => {
  const props = { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke, strokeWidth: 1.6, strokeLinecap: "round", strokeLinejoin: "round" };
  switch (name) {
    case "home":    return <svg {...props}><path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/></svg>;
    case "folder":  return <svg {...props}><path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>;
    case "samples": return <svg {...props}><path d="M4 6h16M4 12h10M4 18h16"/></svg>;
    case "voice":   return <svg {...props}><rect x="9" y="3" width="6" height="12" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/></svg>;
    case "traces":  return <svg {...props}><path d="M4 7h6l2 4 2-8 2 12 2-4h2"/></svg>;
    case "set":     return <svg {...props}><circle cx="12" cy="12" r="3"/><path d="M19 12a7 7 0 0 0-.1-1.2l2-1.6-2-3.4-2.4.9a7 7 0 0 0-2-1.2L14 3h-4l-.5 2.5a7 7 0 0 0-2 1.2l-2.4-.9-2 3.4 2 1.6A7 7 0 0 0 5 12a7 7 0 0 0 .1 1.2l-2 1.6 2 3.4 2.4-.9a7 7 0 0 0 2 1.2L10 21h4l.5-2.5a7 7 0 0 0 2-1.2l2.4.9 2-3.4-2-1.6c.1-.4.1-.8.1-1.2z"/></svg>;
    case "x":       return <svg {...props}><path d="M5 5l14 14M19 5L5 19"/></svg>;
    case "search":  return <svg {...props}><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg>;
    case "play":    return <svg {...props}><polygon points="6 4 20 12 6 20 6 4"/></svg>;
    case "pause":   return <svg {...props}><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>;
    case "rocket":  return <svg {...props}><path d="M14 4l6 6-9 9-3 3-3-3 3-3 9-9z"/><path d="M14 10l4 4M5 21l-1-1"/></svg>;
    case "chev":    return <svg {...props}><polyline points="9 6 15 12 9 18"/></svg>;
    case "expand":  return <svg {...props}><polyline points="6 9 12 15 18 9"/></svg>;
    case "spark":   return <svg {...props}><path d="M12 3l1.6 4.5L18 9l-4.4 1.6L12 15l-1.6-4.4L6 9l4.4-1.5z"/></svg>;
    case "fork":    return <svg {...props}><circle cx="6" cy="6" r="2"/><circle cx="18" cy="6" r="2"/><circle cx="12" cy="20" r="2"/><path d="M6 8v3a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V8M12 13v5"/></svg>;
    case "scan":    return <svg {...props}><path d="M4 7V5a2 2 0 0 1 2-2h2M16 3h2a2 2 0 0 1 2 2v2M20 17v2a2 2 0 0 1-2 2h-2M8 21H6a2 2 0 0 1-2-2v-2M4 12h16"/></svg>;
    case "tree":    return <svg {...props}><path d="M12 4v6M6 14h12M6 14v6M18 14v6M12 10v4"/></svg>;
    case "pen":     return <svg {...props}><path d="M3 21l4-1 12-12-3-3L4 17z"/></svg>;
    case "check":   return <svg {...props}><polyline points="4 12 10 18 20 6"/></svg>;
    case "wave":    return <svg {...props}><path d="M3 12c2 0 2-4 4-4s2 8 4 8 2-8 4-8 2 4 4 4 2 0 2 0"/></svg>;
    case "edit":    return <svg {...props}><path d="M14 4l6 6-10 10H4v-6z"/></svg>;
    case "vector":  return <svg {...props}><circle cx="6" cy="6" r="2"/><circle cx="18" cy="18" r="2"/><path d="M8 8l8 8M6 18l12-12"/></svg>;
    case "image":   return <svg {...props}><rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="11" r="1.5"/><path d="M21 17l-5-5-7 7"/></svg>;
    default: return <svg {...props}><circle cx="12" cy="12" r="3"/></svg>;
  }
};

// ─── Sidebar ────────────────────────────────────────────────────────
const Sidebar = ({ section }) => {
  const items = [
    { id: "dash",    icon: "home",    label: "Dashboard",     count: null },
    { id: "proj",    icon: "folder",  label: "Projects",      count: 12 },
    { id: "brand",   icon: "spark",   label: "Brand voice",   count: null },
    { id: "samples", icon: "samples", label: "Writing samples", count: 24 },
    { id: "voice",   icon: "voice",   label: "Voice notes",   count: 3 },
    { id: "traces",  icon: "traces",  label: "Agent traces",  count: null },
    { id: "set",     icon: "set",     label: "Settings",      count: null },
  ];
  return (
    <aside className="sidebar">
      <div className="nav-label">Workspace</div>
      {items.slice(0, 5).map(it => (
        <div key={it.id} className={"nav-item" + (section === it.id ? " active" : "")}>
          <Icon name={it.icon} />
          <span>{it.label}</span>
          {it.count != null && <span className="count">{String(it.count).padStart(2,"0")}</span>}
        </div>
      ))}
      <div className="nav-label" style={{ marginTop: 14 }}>System</div>
      {items.slice(5).map(it => (
        <div key={it.id} className="nav-item">
          <Icon name={it.icon} />
          <span>{it.label}</span>
        </div>
      ))}
      <div className="nav-label" style={{ marginTop: 14 }}>X Connection</div>
      <div className="nav-item" style={{ display:"grid", gridTemplateColumns:"14px 1fr", gap: 10, padding: "10px 10px" }}>
        <span style={{ width:8, height:8, borderRadius:"50%", background:"var(--green)", boxShadow:"0 0 8px var(--green)", marginTop:5 }} />
        <div>
          <div style={{ fontSize:12, color:"var(--text)" }}>{D.xAccount.name}</div>
          <div className="mono" style={{ fontSize:11, color:"var(--text-3)" }}>{D.xAccount.handle}</div>
        </div>
      </div>
    </aside>
  );
};

// ─── Topbar ────────────────────────────────────────────────────────
const Topbar = ({ onPublish }) => (
  <div className="topbar">
    <div className="brand">
      <div className="logo-mark" />
      <span>nfactorial</span>
      <span style={{ color: "var(--text-3)", marginLeft: 6 }}>::</span>
      <span style={{ color: "var(--text-3)" }}>x-content-platform</span>
    </div>
    <div className="crumbs">
      <span>workspace</span>
      <span className="sep">/</span>
      <span>projects</span>
      <span className="sep">/</span>
      <span className="here">{D.project.id}</span>
    </div>
    <div className="top-spacer" />
    <div className="top-tools">
      <div className="chip"><span className="dot" /> X API · ok · 287/300 rl</div>
      <div className="chip">⌘K · search</div>
      <button className="btn btn-ghost"><Icon name="play" size={12} /> Re-run pipeline</button>
      <button className="btn btn-primary" onClick={onPublish}><Icon name="rocket" size={13} /> Review & publish</button>
    </div>
  </div>
);

// ─── Pipeline stepper ──────────────────────────────────────────────
const stages = [
  { id: "sources",  ix: "01", name: "Sources",    note: "5 retained · 2 internal" },
  { id: "insights", ix: "02", name: "Insights",   note: "3 extracted" },
  { id: "angles",   ix: "03", name: "Angles",     note: "4 ranked · 1 selected" },
  { id: "draft",    ix: "04", name: "Draft",      note: "thread · 5 posts" },
  { id: "review",   ix: "05", name: "Fact + Style", note: "82% / 91%" },
  { id: "publish",  ix: "06", name: "Publish",    note: "ready" },
];

const Pipeline = ({ active, onPick }) => (
  <div className="pipeline">
    {stages.map((s, i) => {
      const idx = stages.findIndex(x => x.id === active);
      const status = i < idx ? "done" : (i === idx ? "active" : "queued");
      return (
        <div key={s.id} className={"stage " + status} onClick={() => onPick(s.id)}>
          <div className="ix mono">{s.ix} · {status.toUpperCase()}</div>
          <div className="name">{s.name}</div>
          <div className="meta">{s.note}</div>
          {status === "active" && <span className="pulse" />}
        </div>
      );
    })}
  </div>
);

// ─── Project header ────────────────────────────────────────────────
const ProjectHeader = ({ t }) => (
  <div className="ph">
    <div className="meta">
      <div className="prompt mono">▸ project::{D.project.id}</div>
      <h1>
        {D.project.title}
        <span className="cursor" />
      </h1>
      <div className="sub">{D.project.topic}. Goal: <em>{D.project.goal}</em>. Audience: {D.project.audience}.</div>
      <div className="stats">
        <div className="s"><div className="lbl">brand voice</div><div className="val">{D.brandVoice.name}</div></div>
        <div className="s"><div className="lbl">format</div><div className="val">Thread · 5 posts</div></div>
        <div className="s"><div className="lbl">quality</div><div className="val"><span className="num">0.86</span> · high</div></div>
        <div className="s"><div className="lbl">fact confidence</div><div className="val"><span style={{ color: "var(--warn)" }}>● </span><span className="num">0.82</span></div></div>
        <div className="s"><div className="lbl">status</div><div className="val" style={{ color: "var(--blue)" }}>● drafting</div></div>
      </div>
    </div>
  </div>
);

// ─── Sources card ──────────────────────────────────────────────────
const TypeIco = ({ t }) => {
  const map = { article: "ART", x_post: "X", paper: "DOI", upload: "PDF", url: "URL" };
  return <div className="tico mono">{map[t] || "··"}</div>;
};

const SourcesPanel = () => (
  <section>
    <div className="section-title">
      <span className="prompt mono">▸</span>
      <h2>Sources & research</h2>
      <span className="hint mono">5 retained · 12 candidates evaluated · credibility ≥ 0.75</span>
      <div className="rule" />
      <button className="btn btn-ghost"><Icon name="search" size={12} /> Add source</button>
    </div>
    <div>
      {D.sources.map(s => (
        <div key={s.id} className="src">
          <TypeIco t={s.type} />
          <div>
            <div className="title">{s.title}</div>
            <div className="snip">"{s.snippet}"</div>
            <div className="row">
              <span>{s.author}</span><span className="dotsep">·</span>
              <span>{s.domain}</span><span className="dotsep">·</span>
              <span>{s.date}</span>
              <span className="dotsep">·</span>
              <span>{s.tags.map(t => "#" + t).join("  ")}</span>
            </div>
          </div>
          <div className="right">
            <div className="cred">cred {s.credibility.toFixed(2)}</div>
            <div className="bar" style={{ marginTop: 6 }}><i style={{ width: `${s.credibility * 100}%` }} /></div>
          </div>
        </div>
      ))}
    </div>
  </section>
);

// ─── Insights ──────────────────────────────────────────────────────
const InsightsPanel = () => (
  <section>
    <div className="section-title">
      <span className="prompt mono">▸</span>
      <h2>Extracted insights</h2>
      <span className="hint mono">non-obvious · evidence-backed · scored 0–1</span>
      <div className="rule" />
    </div>
    <div className="grid-3">
      {D.insights.map((i, ix) => (
        <div key={i.id} className="ins">
          <div className="num">INSIGHT · {String(ix + 1).padStart(2, "0")}</div>
          <div className="claim">{i.claim}</div>
          <div className="why">{i.why}</div>
          <div className="strength">
            <span>strength</span>
            <span className="sbar"><i style={{ width: `${i.strength * 100}%` }} /></span>
            <span className="num">{i.strength.toFixed(2)}</span>
          </div>
        </div>
      ))}
    </div>
  </section>
);

// ─── Angles ────────────────────────────────────────────────────────
const AnglesPanel = ({ pickedId, onPick }) => (
  <section>
    <div className="section-title">
      <span className="prompt mono">▸</span>
      <h2>Angles</h2>
      <span className="hint mono">4 ranked · click to switch active draft</span>
      <div className="rule" />
    </div>
    <div className="grid-2">
      {D.angles.map(a => (
        <div key={a.id} className={"angle" + (pickedId === a.id ? " selected" : "")} onClick={() => onPick(a.id)}>
          <div className="row1">
            <h3>{a.title}</h3>
            <span className="score mono">★ {a.score.toFixed(1)}</span>
          </div>
          <div className="thesis">{a.thesis}</div>
          <div className="meta">
            <span><Icon name="fork" size={11} /> {a.format}</span>
            <span>· tone: {a.tone}</span>
            {pickedId === a.id && <span className="pick"><Icon name="check" size={11} /> SELECTED</span>}
          </div>
        </div>
      ))}
    </div>
  </section>
);

// ─── Draft composer ────────────────────────────────────────────────
const DraftComposer = ({ typingDone, onPublish }) => {
  const [tab, setTab] = useState("thread");
  const [typed, setTyped] = useState(typingDone ? D.draft.posts.length : 0);
  const [charPos, setCharPos] = useState(typingDone ? 9999 : 0);

  useEffect(() => {
    if (typingDone) { setTyped(D.draft.posts.length); setCharPos(9999); return; }
    let stopped = false;
    let cur = 0, pos = 0;
    const step = () => {
      if (stopped) return;
      const post = D.draft.posts[cur];
      if (!post) { setTyped(D.draft.posts.length); return; }
      pos += Math.max(1, Math.floor(Math.random() * 4));
      if (pos >= post.length) {
        setCharPos(post.length);
        setTyped(cur + 1);
        cur += 1; pos = 0;
        if (cur >= D.draft.posts.length) return;
        setTimeout(step, 380);
      } else {
        setCharPos(pos);
        setTimeout(step, 18 + Math.random() * 24);
      }
    };
    setTimeout(step, 600);
    return () => { stopped = true; };
  }, [typingDone]);

  return (
    <section style={{ marginTop: 12 }}>
      <div className="section-title">
        <span className="prompt mono">▸</span>
        <h2>Draft composer</h2>
        <span className="hint mono">writer-agent · streaming · claude-sonnet-4-5</span>
        <div className="rule" />
        <button className="btn btn-ghost"><Icon name="edit" size={12} /> Revise</button>
        <button className="btn btn-primary" onClick={onPublish}><Icon name="rocket" size={12} /> Approve</button>
      </div>

      <div className="draft-shell">
        <div className="draft-tabs">
          {["thread", "text_post", "image_post", "voice_video"].map(k => (
            <div key={k} className={"draft-tab" + (k === tab ? " active" : "")} onClick={() => setTab(k)}>
              {k.replace("_", "-")}
              {k === "thread" && <span style={{ color: "var(--text-3)", marginLeft: 8 }}>5</span>}
            </div>
          ))}
          <div style={{ marginLeft: "auto", padding: "12px 14px", fontFamily: "var(--mono)", fontSize: 11, color: "var(--text-3)", letterSpacing: ".12em", textTransform: "uppercase" }}>
            <span style={{ color: "var(--green)" }}>●</span> live preview
          </div>
        </div>

        <div className="draft-body">
          {D.draft.posts.map((p, i) => {
            const isTyping = i === typed;
            const visible = i < typed ? p : (isTyping ? p.slice(0, charPos) : "");
            if (i > typed) return null;
            const len = visible.length;
            const cls = "thread-post" + (i === typed && !typingDone ? " typing-now" : "");
            return (
              <div key={i} className={cls}>
                <div className="ix">{i + 1}</div>
                <div className="text">
                  {highlightCites(visible)}
                  {isTyping && !typingDone && <span className="typing" />}
                </div>
                <div className="footer">
                  <span className={"len" + (len > 280 ? " over" : "")}>{len}/280</span>
                  <span>reply chain · in_reply_to: {i === 0 ? "—" : `post[${i - 1}]`}</span>
                  {i === 1 && <span style={{ color: "var(--violet)" }}>2 citations</span>}
                  {i === 4 && <span style={{ color: "var(--warn)" }}>style: tighten ending</span>}
                </div>
              </div>
            );
          })}
        </div>

        <div className="draft-bar">
          <span className="ix">▸ thread · {typed}/{D.draft.posts.length} posts ready</span>
          <div className="spacer" />
          <div className="meter">
            <span className="label">quality</span>
            <span className="mbar"><i style={{ width: `${D.draft.quality * 100}%` }} /></span>
            <span className="v num">{D.draft.quality.toFixed(2)}</span>
          </div>
          <div className="meter">
            <span className="label">fact</span>
            <span className="mbar"><i style={{ width: `${D.draft.fact_confidence * 100}%`, background: "var(--warn)" }} /></span>
            <span className="v num">{D.draft.fact_confidence.toFixed(2)}</span>
          </div>
          <div className="meter">
            <span className="label">style</span>
            <span className="mbar"><i style={{ width: `${D.draft.style_score * 100}%`, background: "var(--green)" }} /></span>
            <span className="v num">{D.draft.style_score.toFixed(2)}</span>
          </div>
        </div>
      </div>
    </section>
  );
};

// Helper: wrap factually cited numbers in spans
function highlightCites(text) {
  const re = /(38%|41%|22%|73%|0\.92|5 posts)/g;
  const parts = [];
  let last = 0, m;
  while ((m = re.exec(text)) !== null) {
    if (m.index > last) parts.push(text.slice(last, m.index));
    parts.push(<span key={m.index} className="cite" title={"fact-checked claim · " + m[0]}>{m[0]}</span>);
    last = m.index + m[0].length;
  }
  if (last < text.length) parts.push(text.slice(last));
  return parts;
}

// ─── Fact-check + Style review ─────────────────────────────────────
const verdictLabel = {
  supported: "Supported",
  weakly_supported: "Weak",
  needs_source: "Needs source",
  unsupported: "Unsupported",
};
const verdictCls = {
  supported: "v-supported",
  weakly_supported: "v-weak",
  needs_source: "v-needs",
  unsupported: "v-unsupp",
};

const FactStyle = () => (
  <section style={{ marginTop: 30 }}>
    <div className="grid-2">
      <div>
        <div className="section-title" style={{ margin: "0 0 14px" }}>
          <span className="prompt mono">▸</span>
          <h2>Fact check</h2>
          <span className="hint mono">5 claims · 0.82 overall confidence</span>
          <div className="rule" />
        </div>
        {D.factChecks.map(f => (
          <div key={f.id} className="fc">
            <div>
              <div className="claim">"{f.claim}"</div>
              <div className="src">↳ {f.source || "no source bound — flag for human review"}</div>
              <div className="conf">
                <span>confidence</span>
                <span className="mbar"><i style={{ width: `${f.conf * 100}%`, background: f.conf > 0.8 ? "var(--green)" : f.conf > 0.6 ? "var(--warn)" : "var(--danger)" }} /></span>
                <span className="num">{f.conf.toFixed(2)}</span>
              </div>
            </div>
            <div className={"verdict " + verdictCls[f.verdict]}>{verdictLabel[f.verdict]}</div>
          </div>
        ))}
      </div>
      <div>
        <div className="section-title" style={{ margin: "0 0 14px" }}>
          <span className="prompt mono">▸</span>
          <h2>Style review</h2>
          <span className="hint mono">brand voice · sharp operator</span>
          <div className="rule" />
        </div>
        {D.styleNotes.map((n, i) => (
          <div key={i} className={"stnote " + n.severity}>
            <span className="badge">{n.severity === "good" ? "OK" : "ATTN"}</span>
            <span className="kind">{n.kind}</span>
            <span className="note">{n.note}</span>
          </div>
        ))}
        <div style={{ marginTop: 14, padding: "12px 14px", border: "1px dashed var(--line-2)", borderRadius: 6, fontFamily: "var(--mono)", fontSize: 12, color: "var(--text-3)", lineHeight: 1.6 }}>
          forbidden phrases: <span style={{ color: "var(--text-2)" }}>0 matches</span>
          <br />
          preferred patterns: <span style={{ color: "var(--green)" }}>3/3 applied</span>
          <br />
          reading rhythm:    <span style={{ color: "var(--text-2)" }}>short → medium → short  ✓</span>
        </div>
      </div>
    </div>
  </section>
);

// ─── Right rail: Agent activity ───────────────────────────────────
const AgentRail = ({ openId, setOpen, elapsedMs }) => {
  return (
    <aside className="agent-rail">
      <div className="rail-h">▸ agent pipeline · 10 steps</div>

      {D.agents.map((a, i) => {
        const ms = a.status === "running" ? elapsedMs : a.ms;
        const open = openId === a.id;
        return (
          <div key={a.id} className={"agent " + a.status + (open ? " open" : "")} onClick={() => setOpen(open ? null : a.id)}>
            <div className="sicon"><Icon name={a.icon} size={12} /></div>
            <div>
              <div className="name">{a.name}</div>
              <div className="sub">
                {a.status === "done" && `done · ${a.tokens.toLocaleString()} tok`}
                {a.status === "running" && `running · streaming…`}
                {a.status === "queued" && `queued`}
              </div>
            </div>
            <div className="right">
              <div className="ms">{ms ? `${(ms / 1000).toFixed(2)}s` : "—"}</div>
            </div>

            {open && (
              <div className="detail" onClick={(e) => e.stopPropagation()}>
                <div className="row"><span className="k">model</span>     <span className="v">{a.model}</span></div>
                <div className="row"><span className="k">input</span>     <span className="v">{a.status === "queued" ? "—" : "ContentState · sources×5"}</span></div>
                <div className="row"><span className="k">output</span>    <span className="v">{a.status === "queued" ? "—" : a.id === "writer" ? "draft.posts[0..2/5] (streaming)" : "ok"}</span></div>
                <div className="row"><span className="k">tokens</span>    <span className="v">{a.tokens.toLocaleString()}</span></div>
                <div className="row"><span className="k">latency</span>   <span className="v">{ms ? ms + "ms" : "—"}</span></div>
                {a.id === "factcheck" && a.status === "queued" && <div className="row"><span className="k">queued behind</span><span className="v">writer</span></div>}
              </div>
            )}
          </div>
        );
      })}

      <div className="live-trace">
        <div className="lt-h"><span className="ldot" /> live trace · t-stream</div>
        {D.trace.slice(-7).map((l, i) => (
          <div key={i} className="lt-line">
            <span className="t">{l.t.slice(0, 8)}</span>
            <span className="a">{l.agent}</span>
            <span className="d">{l.detail}</span>
          </div>
        ))}
      </div>

      <div style={{ marginTop: 18, padding: "12px 14px", border: "1px solid var(--line)", borderRadius: 6, background: "rgba(0,0,0,.25)" }}>
        <div className="rail-h" style={{ marginBottom: 8 }}>cost · this run</div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr auto", gap: 6, fontFamily: "var(--mono)", fontSize: 12 }}>
          <span style={{ color: "var(--text-3)" }}>tokens</span>            <span>35,990</span>
          <span style={{ color: "var(--text-3)" }}>tool calls</span>        <span>14</span>
          <span style={{ color: "var(--text-3)" }}>est. cost</span>         <span style={{ color: "var(--blue)" }}>$0.142</span>
          <span style={{ color: "var(--text-3)" }}>budget</span>            <span style={{ color: "var(--text-2)" }}>$2.00 / project</span>
        </div>
      </div>
    </aside>
  );
};

// ─── Publish preview / modal ──────────────────────────────────────
const PublishModal = ({ onClose, onPublished }) => {
  const [phase, setPhase] = useState("review"); // review | publishing | done
  const ts = useRef(null);

  const startPublish = () => {
    setPhase("publishing");
    ts.current = setTimeout(() => {
      setPhase("done");
      onPublished && onPublished();
    }, 2200);
  };
  useEffect(() => () => { if (ts.current) clearTimeout(ts.current); }, []);

  return (
    <div className="modal-back" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ width: 32, height: 32, borderRadius: 8, background: "linear-gradient(135deg,var(--blue),var(--violet))", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <Icon name="rocket" size={16} stroke="#fff" />
          </div>
          <div>
            <div className="h">
              {phase === "review" && "Approve & publish to X"}
              {phase === "publishing" && "Publishing thread…"}
              {phase === "done" && "Published"}
            </div>
            <div className="sub">
              {phase === "review" && `Thread · 5 posts · publishing as ${D.xAccount.handle}`}
              {phase === "publishing" && "Uploading media · creating reply chain · awaiting X API"}
              {phase === "done" && "Reply chain created in 2.1s. Open on X to verify."}
            </div>
          </div>
        </div>

        {phase === "review" && (
          <div style={{ marginTop: 16 }}>
            <div className="preview-thread">
              {D.draft.posts.slice(0, 2).map((p, i) => (
                <div key={i} className="preview-card">
                  <div className="pv-head">
                    <div className="avatar">{D.xAccount.avatarSeed.toUpperCase()}</div>
                    <div>
                      <div className="pv-name">{D.xAccount.name}</div>
                      <div className="pv-handle">{D.xAccount.handle} · now</div>
                    </div>
                  </div>
                  <div className="pv-body">{p}</div>
                  <div className="pv-foot">
                    <span>↺ reply</span><span>↻ rt</span><span>♡ like</span><span>↗ share</span>
                  </div>
                </div>
              ))}
              <div style={{ textAlign: "center", padding: "8px 0", fontFamily: "var(--mono)", fontSize: 11, color: "var(--text-3)" }}>
                + 3 more posts in chain
              </div>
            </div>
            <div style={{ padding: 12, marginTop: 12, background: "rgba(255,180,84,.06)", border: "1px solid rgba(255,180,84,.3)", borderRadius: 6, fontSize: 12.5 }}>
              <span style={{ color: "var(--warn)", fontFamily: "var(--mono)", fontSize: 11, letterSpacing: ".12em", textTransform: "uppercase" }}>● review note</span>
              <div style={{ color: "var(--text-2)", marginTop: 4 }}>
                Claim "Software margins deflating to zero" needs a source. Publish anyway?
              </div>
            </div>
            <div className="modal-actions">
              <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
              <button className="btn">Schedule</button>
              <button className="btn btn-primary" onClick={startPublish}><Icon name="rocket" size={12} /> Publish now</button>
            </div>
          </div>
        )}

        {phase === "publishing" && (
          <div style={{ marginTop: 18 }}>
            {["Uploading media", "Creating post 1/5", "Reply chain 2/5", "Reply chain 3/5", "Reply chain 4/5", "Reply chain 5/5", "Confirming"].map((s, i) => (
              <div key={i} style={{ display: "grid", gridTemplateColumns: "20px 1fr auto", gap: 10, padding: "6px 0", fontFamily: "var(--mono)", fontSize: 12 }}>
                <span style={{ color: "var(--green)" }}>{i < 4 ? "✓" : i === 4 ? "▸" : " "}</span>
                <span style={{ color: i <= 4 ? "var(--text)" : "var(--text-3)" }}>{s}</span>
                <span style={{ color: "var(--text-3)" }}>{i < 4 ? `${(0.2 + i * 0.18).toFixed(2)}s` : ""}</span>
              </div>
            ))}
            <div style={{ height: 4, background: "rgba(255,255,255,.06)", borderRadius: 2, overflow: "hidden", marginTop: 14 }}>
              <div style={{ height: "100%", width: "62%", background: "linear-gradient(90deg,var(--blue),var(--violet))", boxShadow: "0 0 12px var(--blue)" }} />
            </div>
          </div>
        )}

        {phase === "done" && (
          <div style={{ marginTop: 16 }}>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 12 }}>
              <div style={{ padding: 12, border: "1px solid var(--line)", borderRadius: 6 }}>
                <div className="mono" style={{ fontSize: 10, color: "var(--text-3)", letterSpacing: ".12em", textTransform: "uppercase" }}>thread URL</div>
                <div className="mono" style={{ fontSize: 12, color: "var(--blue)", marginTop: 4, wordBreak: "break-all" }}>x.com/nfactorial_hq/status/19283…</div>
              </div>
              <div style={{ padding: 12, border: "1px solid var(--line)", borderRadius: 6 }}>
                <div className="mono" style={{ fontSize: 10, color: "var(--text-3)", letterSpacing: ".12em", textTransform: "uppercase" }}>publish log</div>
                <div className="mono" style={{ fontSize: 12, color: "var(--green)", marginTop: 4 }}>✓ 5/5 posts · 2.18s</div>
              </div>
            </div>
            <div className="modal-actions">
              <button className="btn" onClick={onClose}>Close</button>
              <button className="btn btn-primary">Open on X →</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

// ─── Main app ──────────────────────────────────────────────────────
const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "default",
  "density": "regular",
  "motion": "rich",
  "agentRailOpen": "writer",
  "fastTyping": false
}/*EDITMODE-END*/;

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [activeStage, setActiveStage] = useState("draft");
  const [angle, setAngle] = useState("a1");
  const [openAgent, setOpenAgent] = useState(t.agentRailOpen || "writer");
  const [showPublish, setShowPublish] = useState(false);
  const [elapsed, setElapsed] = useState(2840);

  useEffect(() => { document.body.dataset.density = t.density; }, [t.density]);
  useEffect(() => { document.body.dataset.accent  = t.accent;  }, [t.accent]);
  useEffect(() => { document.body.dataset.motion  = t.motion;  }, [t.motion]);

  useEffect(() => {
    const id = setInterval(() => setElapsed(e => e + (40 + Math.random() * 40)), 90);
    return () => clearInterval(id);
  }, []);

  return (
    <>
      <Topbar onPublish={() => setShowPublish(true)} />
      <div className="layout">
        <Sidebar section="proj" />
        <main className="main">
          <ProjectHeader />
          <Pipeline active={activeStage} onPick={setActiveStage} />
          <SourcesPanel />
          <InsightsPanel />
          <AnglesPanel pickedId={angle} onPick={setAngle} />
          <DraftComposer typingDone={t.fastTyping} onPublish={() => setShowPublish(true)} />
          <FactStyle />
        </main>
        <AgentRail openId={openAgent} setOpen={setOpenAgent} elapsedMs={Math.floor(elapsed)} />
      </div>

      {showPublish && <PublishModal onClose={() => setShowPublish(false)} />}

      <TweaksPanel title="Tweaks">
        <TweakSection label="Theme" />
        <TweakRadio label="Accent" value={t.accent}
          options={["default", "green", "cyber", "amber", "mono"]}
          onChange={(v) => setTweak("accent", v)} />
        <TweakSection label="Layout" />
        <TweakRadio label="Density" value={t.density}
          options={["compact", "regular", "comfy"]}
          onChange={(v) => setTweak("density", v)} />
        <TweakSection label="Motion" />
        <TweakRadio label="Animation" value={t.motion}
          options={["low", "medium", "rich"]}
          onChange={(v) => setTweak("motion", v)} />
        <TweakToggle label="Skip typing animation" value={t.fastTyping}
          onChange={(v) => setTweak("fastTyping", v)} />
        <TweakSection label="Demo" />
        <TweakButton label="Open publish flow" onClick={() => setShowPublish(true)}>Publish modal →</TweakButton>
      </TweaksPanel>
    </>
  );
}

ReactDOM.createRoot(document.getElementById("app")).render(<App />);
