// nfactorial X Content — v3
// Strict black & white editorial layout, X-inspired. One stage at a time.

const { useState, useEffect, useRef } = React;
const D = window.MOCK;

// ─── Icons ──────────────────────────────────────────────────────────
const Icon = ({ name, size = 16, stroke = "currentColor" }) => {
  const p = { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke, strokeWidth: 1.7, strokeLinecap: "round", strokeLinejoin: "round" };
  switch (name) {
    case "home":    return <svg {...p}><path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/></svg>;
    case "folder":  return <svg {...p}><path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>;
    case "voice":   return <svg {...p}><rect x="9" y="3" width="6" height="12" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/></svg>;
    case "lib":     return <svg {...p}><path d="M4 4h6v16H4zM14 4h6v16h-6zM7 8v8M17 8v8"/></svg>;
    case "spark":   return <svg {...p}><path d="M12 3l1.6 4.5L18 9l-4.4 1.6L12 15l-1.6-4.4L6 9l4.4-1.5z"/></svg>;
    case "traces":  return <svg {...p}><path d="M4 7h6l2 4 2-8 2 12 2-4h2"/></svg>;
    case "set":     return <svg {...p}><circle cx="12" cy="12" r="3"/><path d="M19 12a7 7 0 0 0-.1-1.2l2-1.6-2-3.4-2.4.9a7 7 0 0 0-2-1.2L14 3h-4l-.5 2.5a7 7 0 0 0-2 1.2l-2.4-.9-2 3.4 2 1.6A7 7 0 0 0 5 12a7 7 0 0 0 .1 1.2l-2 1.6 2 3.4 2.4-.9a7 7 0 0 0 2 1.2L10 21h4l.5-2.5a7 7 0 0 0 2-1.2l2.4.9 2-3.4-2-1.6c.1-.4.1-.8.1-1.2z"/></svg>;
    case "search":  return <svg {...p}><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg>;
    case "play":    return <svg {...p}><polygon points="6 4 20 12 6 20" fill="currentColor"/></svg>;
    case "rocket":  return <svg {...p}><path d="M14 4l6 6-9 9-3 3-3-3 3-3 9-9z"/><path d="M14 10l4 4M5 21l-1-1"/></svg>;
    case "rt":      return <svg {...p}><path d="M17 1l4 4-4 4M3 11V9a4 4 0 0 1 4-4h14M7 23l-4-4 4-4M21 13v2a4 4 0 0 1-4 4H3"/></svg>;
    case "heart":   return <svg {...p}><path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 1 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8z"/></svg>;
    case "reply":   return <svg {...p}><path d="M3 12h13a5 5 0 0 1 5 5v2M3 12l5-5M3 12l5 5"/></svg>;
    case "share":   return <svg {...p}><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8M16 6l-4-4-4 4M12 2v13"/></svg>;
    case "chart":   return <svg {...p}><path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/></svg>;
    case "edit":    return <svg {...p}><path d="M14 4l6 6-10 10H4v-6z"/></svg>;
    case "check":   return <svg {...p}><polyline points="4 12 10 18 20 6"/></svg>;
    default:        return <svg {...p}><circle cx="12" cy="12" r="3"/></svg>;
  }
};

// ─── Topbar ────────────────────────────────────────────────────────
const Topbar = ({ onPublish }) => (
  <div className="topbar">
    <div className="brand">
      <div className="mark">n</div>
      <span className="name">nfactorial</span>
    </div>
    <div className="breadcrumb">
      <span>Projects</span>
      <span className="sep">/</span>
      <span className="current">Why we're building agentic content infra</span>
      <span className="id">{D.project.id}</span>
    </div>
    <div className="top-actions">
      <div className="chip"><span className="dot" /> Drafting</div>
      <button className="btn"><Icon name="play" size={12} /> Re-run</button>
      <button className="btn btn-primary" onClick={onPublish}><Icon name="rocket" size={14} /> Publish</button>
    </div>
  </div>
);

// ─── Sidebar ───────────────────────────────────────────────────────
const Sidebar = () => (
  <aside className="sidebar">
    <div className="nav-group">
      <div className="nav-item"><Icon name="home" size={18} /> <span>Dashboard</span></div>
      <div className="nav-item active"><Icon name="folder" size={18} /> <span>Projects</span><span className="count">12</span></div>
      <div className="nav-item"><Icon name="spark" size={18} /> <span>Brand voice</span></div>
      <div className="nav-item"><Icon name="lib" size={18} /> <span>Samples</span><span className="count">24</span></div>
      <div className="nav-item"><Icon name="voice" size={18} /> <span>Voice notes</span><span className="count">3</span></div>
    </div>
    <div className="nav-group">
      <div className="nav-label">Account</div>
      <div className="nav-item">
        <div style={{ width: 28, height: 28, borderRadius: "50%", background: "linear-gradient(135deg, #fff, #888)", display: "flex", alignItems: "center", justifyContent: "center", color: "#000", fontWeight: 700, fontSize: 12 }}>N</div>
        <div style={{ display: "flex", flexDirection: "column", gap: 0, lineHeight: 1.3 }}>
          <span style={{ fontSize: 13, color: "var(--text)" }}>{D.xAccount.name}</span>
          <span style={{ fontSize: 12, color: "var(--text-3)", fontFamily: "var(--mono)" }}>{D.xAccount.handle}</span>
        </div>
      </div>
    </div>
    <div className="nav-group">
      <div className="nav-label">System</div>
      <div className="nav-item"><Icon name="traces" size={18} /> <span>Activity</span></div>
      <div className="nav-item"><Icon name="set" size={18} /> <span>Settings</span></div>
    </div>
  </aside>
);

// ─── Stages tabs ───────────────────────────────────────────────────
const STAGES = [
  { id: "sources",  num: "01", name: "Sources" },
  { id: "insights", num: "02", name: "Insights" },
  { id: "angles",   num: "03", name: "Angles" },
  { id: "draft",    num: "04", name: "Draft" },
  { id: "review",   num: "05", name: "Review" },
  { id: "publish",  num: "06", name: "Publish" },
];

const StagesNav = ({ active, onPick }) => {
  const idx = STAGES.findIndex(s => s.id === active);
  return (
    <nav className="stages">
      {STAGES.map((s, i) => (
        <div key={s.id}
             className={"stage-tab " + (i < idx ? "done " : "") + (s.id === active ? "active" : "")}
             onClick={() => onPick(s.id)}>
          <span className="num">{s.num}</span>
          <span>{s.name}</span>
        </div>
      ))}
    </nav>
  );
};

// ─── Project headline ──────────────────────────────────────────────
const ProjectHeader = () => (
  <div className="ph">
    <div className="eyebrow">
      <span className="dot" />
      <span>Draft in progress</span>
      <span style={{ color: "var(--text-4)" }}>·</span>
      <span>Thread · 5 posts</span>
      <span style={{ color: "var(--text-4)" }}>·</span>
      <span>Sharp Operator voice</span>
    </div>
    <h1>Why we're building agentic content infra.</h1>
    <p>Distribution is the new moat for AI-native startups. nfactorial researches, drafts, fact-checks and publishes posts to X — with humans at every gate.</p>
  </div>
);

// ─── Sources ────────────────────────────────────────────────────────
const StageSources = () => {
  const typeMap = { article: "ART", x_post: "X", paper: "DOI", upload: "PDF", url: "URL" };
  return (
    <div className="stage-body">
      <div className="stage-h">
        <div>
          <h2>Sources</h2>
          <div className="desc">5 retained from 12 candidates · credibility ≥ 0.75</div>
        </div>
        <div className="actions">
          <button className="btn"><Icon name="search" size={14} /> Add source</button>
        </div>
      </div>
      <div className="src-list">
        {D.sources.map(s => (
          <div key={s.id} className="src-row">
            <div className="src-tag">{typeMap[s.type]}</div>
            <div>
              <div className="src-title">{s.title}</div>
              <div className="src-snip">"{s.snippet}"</div>
              <div className="src-meta">
                {s.author}<span className="dot">·</span>{s.domain}<span className="dot">·</span>{s.date}
              </div>
            </div>
            <div className="src-cred">
              <div className="v">{s.credibility.toFixed(2)}</div>
              <div className="k">credibility</div>
              <div className="bar"><i style={{ width: `${s.credibility * 100}%` }} /></div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// ─── Insights ───────────────────────────────────────────────────────
const StageInsights = () => (
  <div className="stage-body">
    <div className="stage-h">
      <div>
        <h2>Insights</h2>
        <div className="desc">3 non-obvious claims extracted, ranked by evidence strength</div>
      </div>
    </div>
    <div className="ins-list">
      {D.insights.map((i, ix) => (
        <div key={i.id} className="ins-row">
          <div className="ix">{String(ix + 1).padStart(2, "0")}</div>
          <div>
            <div className="ins-claim">{i.claim}</div>
            <div className="ins-why">{i.why}</div>
          </div>
          <div className="ins-strength">
            <div className="v">{i.strength.toFixed(2)}</div>
            <div className="k">strength</div>
            <div className="bar"><i style={{ width: `${i.strength * 100}%` }} /></div>
          </div>
        </div>
      ))}
    </div>
  </div>
);

// ─── Angles ────────────────────────────────────────────────────────
const StageAngles = ({ pick, setPick }) => (
  <div className="stage-body">
    <div className="stage-h">
      <div>
        <h2>Angles</h2>
        <div className="desc">4 ranked angles · the selected one drives the draft</div>
      </div>
    </div>
    <div className="ang-grid">
      {D.angles.map(a => (
        <div key={a.id} className={"ang-card" + (a.id === pick ? " sel" : "")} onClick={() => setPick(a.id)}>
          <div className="ac-head">
            <div className="ac-title">{a.title}</div>
            <div className="ac-score">★ {a.score.toFixed(1)}</div>
          </div>
          <div className="ac-thesis">{a.thesis}</div>
          <div className="ac-foot">
            <span>{a.format}</span>
            <span>{a.tone}</span>
            {a.id === pick && <span className="selected-tag"><Icon name="check" size={13} /> Selected</span>}
          </div>
        </div>
      ))}
    </div>
  </div>
);

// ─── Draft (composer + X preview) ──────────────────────────────────
const StageDraft = ({ typingDone, onPublish }) => {
  const posts = D.draft.posts;
  const [typed, setTyped] = useState(typingDone ? posts.length : 0);
  const [charPos, setCharPos] = useState(typingDone ? 9999 : 0);

  useEffect(() => {
    if (typingDone) { setTyped(posts.length); setCharPos(9999); return; }
    let stopped = false;
    let cur = 0, pos = 0;
    const step = () => {
      if (stopped) return;
      const post = posts[cur];
      if (!post) { setTyped(posts.length); return; }
      pos += Math.max(1, Math.floor(Math.random() * 4));
      if (pos >= post.length) {
        setCharPos(post.length); setTyped(cur + 1);
        cur += 1; pos = 0;
        if (cur >= posts.length) return;
        setTimeout(step, 380);
      } else {
        setCharPos(pos);
        setTimeout(step, 18 + Math.random() * 24);
      }
    };
    setTimeout(step, 500);
    return () => { stopped = true; };
  }, [typingDone]);

  return (
    <div className="stage-body">
      <div className="stage-h">
        <div>
          <h2>Draft</h2>
          <div className="desc">writer-agent streaming · publishes as {D.xAccount.handle}</div>
        </div>
        <div className="actions">
          <button className="btn"><Icon name="edit" size={14} /> Revise</button>
          <button className="btn btn-primary" onClick={onPublish}><Icon name="check" size={14} /> Approve</button>
        </div>
      </div>

      <div className="draft-shell">
        <div className="draft-side">
          <h4><span className="ind" /> Composer · {typed}/{posts.length}</h4>
          {posts.map((p, i) => {
            if (i > typed) return null;
            const isTyping = i === typed && !typingDone;
            const visible = i < typed ? p : (isTyping ? p.slice(0, charPos) : "");
            const len = visible.length;
            return (
              <div key={i} className="tp">
                <div className={"ix" + (isTyping ? " streaming" : "")}>{i + 1}</div>
                <div className="text">{highlightCites(visible)}{isTyping && <span className="typing" />}</div>
                <div className="foot">
                  <span className={len > 280 ? "over" : ""}>{len}/280</span>
                  {i > 0 && <span>↳ replies to {i}</span>}
                  {i === 1 && <span>2 citations</span>}
                </div>
              </div>
            );
          })}
        </div>

        <div className="preview-thread">
          <h4>Preview</h4>
          <div className="x-frame">
            {posts.slice(0, 3).map((p, i) => (
              <div key={i} className="pv">
                <div className="pv-av">
                  N
                  {i < 2 && <div className="pv-thread-line" />}
                </div>
                <div>
                  <div className="pv-head">
                    <span className="pv-name">{D.xAccount.name}</span>
                    <span className="pv-handle">{D.xAccount.handle}</span>
                    <span className="pv-dot">·</span>
                    <span className="pv-time">now</span>
                  </div>
                  <div className="pv-body">{p}</div>
                  <div className="pv-foot">
                    <span className="action"><Icon name="reply" size={15} /> 12</span>
                    <span className="action"><Icon name="rt" size={15} /> 4</span>
                    <span className="action"><Icon name="heart" size={15} /> 28</span>
                    <span className="action"><Icon name="share" size={15} /></span>
                  </div>
                </div>
              </div>
            ))}
            <div style={{ padding: "14px 20px", textAlign: "center", color: "var(--text-3)", fontSize: 13, borderTop: "1px solid var(--border)" }}>
              + 2 more posts in this thread
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

function highlightCites(text) {
  const re = /(38%|41%|22%|73%|0\.92)/g;
  const parts = [];
  let last = 0, m;
  while ((m = re.exec(text)) !== null) {
    if (m.index > last) parts.push(text.slice(last, m.index));
    parts.push(<span key={m.index} className="cite" title={"fact-checked · " + m[0]}>{m[0]}</span>);
    last = m.index + m[0].length;
  }
  if (last < text.length) parts.push(text.slice(last));
  return parts;
}

// ─── Review ─────────────────────────────────────────────────────────
const StageReview = () => {
  const verdictLabel = { supported: "Supported", weakly_supported: "Weak", needs_source: "Needs source" };
  const verdictCls = { supported: "v-supported", weakly_supported: "v-weak", needs_source: "v-needs" };
  const overall = D.draft.fact_confidence;
  const circ = 2 * Math.PI * 64;
  const dash = circ * overall;
  const counts = D.factChecks.reduce((acc, f) => ((acc[f.verdict] = (acc[f.verdict] || 0) + 1), acc), {});

  return (
    <div className="stage-body">
      <div className="stage-h">
        <div>
          <h2>Review</h2>
          <div className="desc">Fact check across 5 claims · style review against brand voice</div>
        </div>
      </div>

      <div className="review-shell">
        <div className="fc-list">
          {D.factChecks.map(f => (
            <div key={f.id} className="fc">
              <div>
                <div className="claim">{f.claim}</div>
                <div className="src">↳ {f.source || "No source bound · flagged for human review"}</div>
              </div>
              <div className={"verdict " + verdictCls[f.verdict]}>{verdictLabel[f.verdict]}</div>
            </div>
          ))}
        </div>

        <div className="conf-summary">
          <div className="label">Overall confidence</div>
          <svg className="ring" viewBox="0 0 160 160">
            <circle cx="80" cy="80" r="64" fill="none" stroke="var(--border)" strokeWidth="6" />
            <circle cx="80" cy="80" r="64" fill="none" stroke="#fff" strokeWidth="6"
              strokeDasharray={`${dash} ${circ - dash}`}
              strokeLinecap="round"
              transform="rotate(-90 80 80)"
              style={{ transition: "stroke-dasharray .6s ease" }}
            />
            <text x="80" y="84" textAnchor="middle" fill="currentColor"
              style={{ fontFamily: "var(--mono)", fontSize: 30, fontWeight: 600 }}>
              {Math.round(overall * 100)}
            </text>
            <text x="80" y="106" textAnchor="middle" fill="var(--text-3)"
              style={{ fontFamily: "var(--mono)", fontSize: 10, letterSpacing: "0.18em" }}>
              %
            </text>
          </svg>
          <div className="conf-breakdown">
            <div className="b">
              <div className="v">{counts.supported || 0}</div>
              <div className="k">supported</div>
            </div>
            <div className="b">
              <div className="v">{counts.weakly_supported || 0}</div>
              <div className="k">weak</div>
            </div>
            <div className="b">
              <div className="v">{counts.needs_source || 0}</div>
              <div className="k">needs src</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// ─── Publish ────────────────────────────────────────────────────────
const StagePublish = ({ onPublish }) => {
  const posts = D.draft.posts;
  const checks = [
    { ok: true,  label: "X account connected",      val: D.xAccount.handle },
    { ok: true,  label: "Brand voice applied",       val: "Sharp Operator" },
    { ok: true,  label: "Thread structure valid",    val: "5 / 5 posts" },
    { ok: false, label: "1 claim needs a source",    val: "post 3" },
    { ok: true,  label: "Style review passed",       val: "0.91" },
  ];
  return (
    <div className="stage-body">
      <div className="stage-h">
        <div>
          <h2>Publish</h2>
          <div className="desc">Final preview · approve to push the reply chain to X</div>
        </div>
      </div>

      <div className="pub-shell">
        <div className="x-frame">
          {posts.slice(0, 3).map((p, i) => (
            <div key={i} className="pv">
              <div className="pv-av">
                N
                {i < 2 && <div className="pv-thread-line" />}
              </div>
              <div>
                <div className="pv-head">
                  <span className="pv-name">{D.xAccount.name}</span>
                  <span className="pv-handle">{D.xAccount.handle}</span>
                  <span className="pv-dot">·</span>
                  <span className="pv-time">scheduled</span>
                </div>
                <div className="pv-body">{p}</div>
              </div>
            </div>
          ))}
          <div style={{ padding: "14px 20px", textAlign: "center", color: "var(--text-3)", fontSize: 13, borderTop: "1px solid var(--border)" }}>
            + 2 more posts in this thread
          </div>
        </div>

        <div className="pub-summary">
          <h3>Ready to publish</h3>
          <div className="sub">Thread · 5 posts · {D.xAccount.handle}</div>

          <div className="pub-checks">
            {checks.map((c, i) => (
              <div key={i} className="pl-check">
                <span className={c.ok ? "ok" : "warn"}>{c.ok ? "✓" : "○"}</span>
                <span>{c.label}</span>
                <span className="v">{c.val}</span>
              </div>
            ))}
          </div>

          <div className="schedule-line">
            <div>
              <div className="k">Schedule</div>
              <div className="v" style={{ marginTop: 2 }}>Today · 14:30 UTC</div>
            </div>
            <span style={{ flex: 1 }} />
            <button className="btn btn-ghost" style={{ height: 28, padding: "0 12px", fontSize: 12 }}>edit</button>
          </div>

          <button className="launch-btn" onClick={onPublish}>
            Publish thread
          </button>
        </div>
      </div>
    </div>
  );
};

// ─── Stage router ──────────────────────────────────────────────────
const Stage = ({ id, picks, setPicks, onPublish, typingDone }) => {
  switch (id) {
    case "sources":  return <StageSources />;
    case "insights": return <StageInsights />;
    case "angles":   return <StageAngles pick={picks.angle} setPick={(v) => setPicks(p => ({ ...p, angle: v }))} />;
    case "draft":    return <StageDraft typingDone={typingDone} onPublish={onPublish} />;
    case "review":   return <StageReview />;
    case "publish":  return <StagePublish onPublish={onPublish} />;
    default: return null;
  }
};

// ─── Publish modal ─────────────────────────────────────────────────
const PublishModal = ({ onClose }) => {
  const [phase, setPhase] = useState("review");
  const ts = useRef(null);
  const start = () => {
    setPhase("publishing");
    ts.current = setTimeout(() => setPhase("done"), 2200);
  };
  useEffect(() => () => { if (ts.current) clearTimeout(ts.current); }, []);

  return (
    <div className="modal-back" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <div className="modal-h">
          {phase === "review"     && "Publish thread to X"}
          {phase === "publishing" && "Publishing…"}
          {phase === "done"       && "Published"}
        </div>
        <div className="modal-sub">
          {phase === "review"     && `5 posts · ${D.xAccount.handle}`}
          {phase === "publishing" && "Creating reply chain"}
          {phase === "done"       && "Thread is live on X. 2.18s."}
        </div>

        {phase === "review" && (
          <>
            <div style={{ marginTop: 18, padding: "14px 16px", border: "1px solid var(--border-2)", borderRadius: 12, fontSize: 13.5, color: "var(--text-2)" }}>
              <span style={{ color: "var(--text)", fontWeight: 500 }}>1 claim needs a source.</span> Publish anyway, or pause to add one?
            </div>
            <div className="modal-actions">
              <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
              <button className="btn">Pause</button>
              <button className="btn btn-primary" onClick={start}>Publish now</button>
            </div>
          </>
        )}

        {phase === "publishing" && (
          <div style={{ marginTop: 18 }}>
            {["Uploading", "Post 1/5", "Post 2/5", "Post 3/5", "Post 4/5", "Post 5/5", "Confirming"].map((s, i) => (
              <div key={i} style={{ display: "grid", gridTemplateColumns: "20px 1fr auto", gap: 10, padding: "8px 0", fontSize: 14, borderBottom: "1px solid var(--border)" }}>
                <span style={{ color: i < 4 ? "var(--text)" : i === 4 ? "var(--text)" : "var(--text-3)" }}>{i < 4 ? "✓" : i === 4 ? "○" : ""}</span>
                <span style={{ color: i <= 4 ? "var(--text)" : "var(--text-3)" }}>{s}</span>
                <span style={{ fontFamily: "var(--mono)", color: "var(--text-3)", fontSize: 12 }}>{i < 4 ? `${(0.2 + i * 0.18).toFixed(2)}s` : ""}</span>
              </div>
            ))}
            <div style={{ height: 3, background: "var(--border)", borderRadius: 2, marginTop: 16, overflow: "hidden" }}>
              <div style={{ height: "100%", width: "65%", background: "#fff", transition: "width .4s ease" }} />
            </div>
          </div>
        )}

        {phase === "done" && (
          <>
            <div style={{ marginTop: 18, padding: "16px 18px", border: "1px solid var(--border-2)", borderRadius: 12 }}>
              <div style={{ fontFamily: "var(--mono)", fontSize: 10, letterSpacing: ".18em", textTransform: "uppercase", color: "var(--text-3)" }}>Thread URL</div>
              <div style={{ fontFamily: "var(--mono)", fontSize: 13, color: "var(--text)", marginTop: 4 }}>x.com/nfactorial_hq/status/19283…</div>
            </div>
            <div className="modal-actions">
              <button className="btn" onClick={onClose}>Close</button>
              <button className="btn btn-primary">Open on X →</button>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

// ─── App ───────────────────────────────────────────────────────────
const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "theme": "dark",
  "density": "regular",
  "fastTyping": false
}/*EDITMODE-END*/;

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [active, setActive] = useState("draft");
  const [picks, setPicks] = useState({ angle: "a1" });
  const [showPublish, setShowPublish] = useState(false);

  useEffect(() => { document.body.dataset.density = t.density; }, [t.density]);
  useEffect(() => { document.body.dataset.theme   = t.theme;   }, [t.theme]);

  return (
    <>
      <Topbar onPublish={() => setShowPublish(true)} />
      <div className="layout">
        <Sidebar />
        <main className="main">
          <ProjectHeader />
          <StagesNav active={active} onPick={setActive} />
          <Stage key={active} id={active} picks={picks} setPicks={setPicks}
                 onPublish={() => setShowPublish(true)}
                 typingDone={t.fastTyping} />
        </main>
      </div>

      {showPublish && <PublishModal onClose={() => setShowPublish(false)} />}

      <TweaksPanel title="Tweaks">
        <TweakSection label="Theme" />
        <TweakRadio label="Mode" value={t.theme}
          options={["dark", "light"]}
          onChange={(v) => setTweak("theme", v)} />
        <TweakSection label="Layout" />
        <TweakRadio label="Density" value={t.density}
          options={["compact", "regular", "comfy"]}
          onChange={(v) => setTweak("density", v)} />
        <TweakToggle label="Skip typing animation" value={t.fastTyping}
          onChange={(v) => setTweak("fastTyping", v)} />
        <TweakSection label="Jump to stage" />
        <TweakRadio label="Stage" value={active}
          options={["sources", "insights", "angles", "draft", "review", "publish"]}
          onChange={setActive} />
      </TweaksPanel>
    </>
  );
}

ReactDOM.createRoot(document.getElementById("app")).render(<App />);
